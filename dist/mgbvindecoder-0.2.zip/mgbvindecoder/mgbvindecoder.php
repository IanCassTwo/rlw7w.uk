<?php
/*
Plugin Name: MGB Vin Decoder
Plugin URI: https://rlw7w.uk/
Description: A Vin Decoder for MGB
Author: Ian Cass
Version: 0.2
Author URI: https://rlw7w.uk
*/
 


function mgbvindecoder_form_creation() {
	ob_start(); // start a buffer
	?>
	<input type="text" name="vin" id="vin" required>
	<button id="button" type="button" onclick="vindecoder()">Submit</button>
	<script>
	var input = document.getElementById("vin");
	input.addEventListener("keyup", function(event) {
	console.log(event.keyCode);
	  if (event.keyCode === 13) {
	   event.preventDefault();
	   document.getElementById("button").click();
	  }
	});
	</script>
	<p id="demo"</p>
	<?php
	$wanted = ob_get_clean();
	return $wanted;

}
add_shortcode("mgbvindecoder", "mgbvindecoder_form_creation");

function mgbvindecoder_enqueue_script()
{   
    wp_enqueue_script( 'vindecoder', plugin_dir_url( __FILE__ ) . '/js/vindecoder.js');
}
add_action('wp_enqueue_scripts', 'mgbvindecoder_enqueue_script');

?>
